import React from 'react'

import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import CardMedia from '@mui/material/CardMedia';
import Typography from '@mui/material/Typography';

// icons
import AcUnitIcon from '@mui/icons-material/AcUnit';
import ThunderstormIcon from '@mui/icons-material/Thunderstorm';
import WbSunnyIcon from '@mui/icons-material/WbSunny';


export default function InfoBox({info}) {
    let ini_url = "https://th.bing.com/th/id/OIP.eGpwaVxhf3ZLac_Om3pJmQHaLH?w=182&h=273&c=7&r=0&o=5&dpr=1.3&pid=1.7";
    let cold_img = "https://www.climaterealityproject.org/sites/default/files/timothy-eberly-lhm2nldtc9g-unsplash.jpg"
    let hot_img = "https://www.treehugger.com/thmb/emVFfdc5Dwzu-u531n2zOSyvkLc=/1500x0/filters:no_upscale():max_bytes(150000):strip_icc()/__opt__aboutcom__coeus__resources__content_migration__mnn__images__2018__07__palm_trees_hot_sun-f8e20b86425b492f9d777d92db46db49.jpg"
    let rain_img = "https://images.unsplash.com/photo-1620053111049-81ee03172abf?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=MnwxMjA3fDB8MXxzZWFyY2h8M3x8cmFpbnklMjBkYXl8fDB8fHx8MTYyOTMzNTM1NA&ixlib=rb-1.2.1&q=80&w=1080"

    return (
    <div className='infoBox'>
      <h2>weather info - {info.weather}</h2>

      <Card sx={{ maxWidth: 345 }}>
      <CardMedia
        component="img"
        alt="green iguana"
        height="140"
        image = {info.humidity> 80 ? rain_img : (info.temp <=15 ? cold_img : hot_img)}
      />
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          {info.city} {info.humidity> 80 ? <ThunderstormIcon/> : (info.temp <=15 ? <AcUnitIcon/> : <WbSunnyIcon/>)}
        </Typography>
        <Typography variant="body2" color="text.secondary" >
         <p> temperature : {info.temp}&deg;C</p>
         <p> humidity : {info.humidity}</p>
         <p> feelslike : {info.feelslike}</p>
         <p> tempMax : {info.tempMax}&deg;C</p>
         <p> tempMin : {info.tempMin}&deg;C</p>
         <p> weather can be described as {info.weather} and temperature is {info.temp}&deg;C</p>
        </Typography>
      </CardContent>
      
    </Card>
    </div>
  )
}
