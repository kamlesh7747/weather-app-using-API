// weather.jsx

import React, { useState } from "react";
import InfoBox from "./InfoBox";
import Search from "./Search";

export default function Weather() {
  let [weatherInfo, setInfo] = useState({
    city: "bangalore",
    feelslike: "haze",
    humidity: 83,
    temp: 297.71,
    tempMax: 297.95,
    tempMin: 297.05,
    weather: "broken clouds",
  });

  // to update data
  let updateInfo = (new_info) => {
    setInfo(new_info);
  };
  return (
    <div>
      <h1>Weather App</h1>
      <Search updateInfo={updateInfo}></Search>
      <InfoBox info={weatherInfo} setInfo={setInfo}></InfoBox>
    </div>
  );
}
