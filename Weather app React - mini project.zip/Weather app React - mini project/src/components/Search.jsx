import React, { useState } from "react";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import SearchIcon from "@mui/icons-material/Search";

export default function Search({ updateInfo }) {
  const [city, setCity] = useState("");
  const [error, setError] = useState(false);

  const API_key = "1781ca04586f4c4ed7bdbe519db4ed2e";
  const API_URL = "https://api.openweathermap.org/data/2.5/weather";

  let getWeatherInfo = async () => {
    try {
      let response = await fetch(
        `${API_URL}?q=${city}&appid=${API_key}&units=metric`
      );

      if (!response.ok) {
        throw new Error("Weather data not found");
      }

      let jsonResponse = await response.json();

      let result = {
        city: city,
        temp: jsonResponse.main.temp,
        tempMin: jsonResponse.main.temp_min,
        tempMax: jsonResponse.main.temp_max,
        humidity: jsonResponse.main.humidity,
        feelslike: jsonResponse.main.feels_like,
        weather: jsonResponse.weather[0].description,
      };

      return result;
    } catch (err) {
      setError(true);
      console.error("Error fetching weather:", err);
      throw err;
    }
  };

  const handleChange = (event) => {
    setCity(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      setCity("");
      let new_info = await getWeatherInfo();
      updateInfo(new_info);
      setError(false);
    } catch (err) {
      setError(true);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <TextField
        onChange={handleChange}
        required
        id="city"
        label="City Name"
        placeholder="Enter city name"
        value={city}
      />
      <br /> <br />
      <Button
        type="submit"
        variant="contained"
        color="primary"
        endIcon={<SearchIcon />}
      >
        Search
      </Button>
      {error && <p style={{ color: "red" }}>No data found!</p>}
    </form>
  );
}
